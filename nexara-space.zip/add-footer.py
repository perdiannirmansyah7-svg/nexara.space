from pathlib import Path

footer = """
<style>
.nexara-footer {
  text-align: center;
  padding: 28px 15px;
  margin-top: 50px;
  border-top: 1px solid #24344f;
  color: #aab8d0;
  font-family: Arial, sans-serif;
}
.nexara-footer strong {
  color: #67d5ff;
}
.nexara-footer small {
  display: block;
  margin-top: 8px;
  color: #718096;
}
</style>
<footer class="nexara-footer">
  <strong>Created by Perdian Nirmansyah</strong>
  <small>© 2026 NEXARA SPACE — Explore The Universe</small>
</footer>
"""

for file in Path(".").glob("*.html"):
    content = file.read_text(encoding="utf-8")
    if "Created by Perdian Nirmansyah" not in content:
        content = content.replace("</body>", footer + "\n</body>")
        file.write_text(content, encoding="utf-8")
        print("Berhasil:", file.name)

print("SELESAI!")
